# NAHDA — Fast Static HTML Deployment

This is a static HTML site. It does not need Python, `main.py`, `package.json`, a build script, or a serverless function.

## Deploy to Vercel
1. Extract this ZIP.
2. Put `index.html` and `vercel.json` in the ROOT of the GitHub repository connected to Vercel.
3. In Vercel → Project → Settings → Build and Deployment:
   - Framework Preset: **Other**
   - Root Directory: the folder containing `index.html` (normally repository root)
   - Build Command: **Override disabled / empty**
   - Output Directory: **Override disabled / empty**
   - Install Command: **Override disabled / empty**
4. In the repository, remove any old `vercel.json` or deployment config that defines a Python builder/runtime or references `main.py`. Keep the included `vercel.json`.
5. Commit and push to the branch Vercel deploys.
6. In Vercel → Deployments, redeploy the newest commit and open its generated `.vercel.app` URL.

## If PYTHON_ENTRYPOINT_NOT_FOUND still appears
That error is caused by a Python build/entrypoint setting or an old deployment configuration, not by this HTML file. Check that Vercel is connected to the intended repository and production branch, and that no project setting or config file is forcing Python. This package does not change settings in your Vercel account automatically.
