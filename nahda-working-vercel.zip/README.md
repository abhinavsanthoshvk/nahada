# NAHDA – Gold & Diamonds: Vercel deployment fix

This package contains the original single-page website plus a Vercel rewrite configuration.

## Files
- `index.html` — original NAHDA website
- `vercel.json` — serves the homepage for routes that otherwise return Vercel 404

## Deploy correctly
1. Extract this ZIP.
2. Upload `index.html` and `vercel.json` to the ROOT of the GitHub repository (not inside an extra nested folder).
3. In Vercel → Project → Settings → Build and Deployment:
   - Framework Preset: Other
   - Root Directory: `.` / repository root (the folder containing `index.html`)
   - Build Command: leave empty / override disabled
   - Output Directory: leave empty / override disabled
4. Commit and push the files to GitHub, or import the repository in Vercel.
5. In Vercel → Deployments, redeploy the latest commit and open the new deployment URL.

Note: the supplied site is a single-page HTML website. Its navigation uses section anchors such as #home, #products, and #contact; it does not include separate HTML files for independent pages. The rewrite prevents unknown paths from showing Vercel's 404, but it does not create new unique page content.
