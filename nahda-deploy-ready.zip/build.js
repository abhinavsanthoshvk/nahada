const fs = require("fs");
const path = require("path");

const root = __dirname;
const output = path.join(root, "dist");
const source = path.join(root, "index.html");

if (!fs.existsSync(source)) {
  console.error("Build failed: index.html was not found in the repository root.");
  process.exit(1);
}

fs.rmSync(output, { recursive: true, force: true });
fs.mkdirSync(output, { recursive: true });
fs.copyFileSync(source, path.join(output, "index.html"));

console.log("NAHDA static website built successfully into dist/.");
