# NAHDA – Gold & Diamonds | Vercel deployment-ready package

This is a static HTML website. It does not use Python and does not need `main.py`.

## Files
- `index.html`: original website
- `package.json`: build script declaration
- `build.js`: creates the `dist` deployment folder
- `vercel.json`: tells Vercel to build the site and publish `dist`

## Important deployment steps
1. Extract this ZIP.
2. In the GitHub repository connected to Vercel, put `index.html`, `package.json`, `build.js`, and `vercel.json` directly in the repository root. Do not upload the ZIP itself and do not put these files inside an extra nested folder.
3. In Vercel → Project → Settings → Build and Deployment, set Framework Preset to **Other**.
4. Set Root Directory to the repository root.
5. Use Build Command `npm run build` and Output Directory `dist` (or leave settings to use `vercel.json`; do not set a conflicting output directory).
6. Commit and push the files to the branch Vercel deploys.
7. In Vercel → Deployments, confirm the newest deployment is marked **Ready**, then open that deployment's URL.

If the new deployment still shows Vercel's 404 page, verify that Vercel is connected to the correct GitHub repository and production branch, and that the latest deployment contains these four files at the root. This package cannot change project settings or trigger a deployment in your account automatically.
